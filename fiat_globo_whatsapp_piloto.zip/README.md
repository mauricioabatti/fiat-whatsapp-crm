# Fiat Globo WhatsApp Piloto

Este é um projeto piloto em Flask para demonstração de atendimento via WhatsApp integrado com Twilio.

## Rotas
- `/whatsapp` → recebe mensagens do WhatsApp e responde automaticamente.
- `/painel` → painel simples de leads coletados.

## Deploy
Compatível com Railway (Dockerfile + railway.toml inclusos).
